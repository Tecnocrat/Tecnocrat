code_snippet = "def add(a, b): return a + b"
explanation = explain_python_code(code_snippet)
print(explanation)