# filepath: C:\dev\AIOS\scripts\test_env.py
import flask
import requests
import numpy

print("Virtual environment is working!")