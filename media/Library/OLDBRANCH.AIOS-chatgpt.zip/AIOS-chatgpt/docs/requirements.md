https://cppcheck.sourceforge.io/
https://cmake.org/download/
https://www.anaconda.com/docs/getting-started/miniconda/main