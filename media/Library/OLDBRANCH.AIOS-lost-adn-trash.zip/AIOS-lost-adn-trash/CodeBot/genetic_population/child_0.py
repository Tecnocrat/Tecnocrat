# filepath: c:\dev\CodeBot\example.py
import os


def example_function():
    print("This is an example function.")
